@extends('back-end.layouts.master')
@section('dashboard')
    active
@endsection
@section('main-content')
<div class="container-fluid dashboard-content ">

</div>
@endsection